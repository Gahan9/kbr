NAME_OF_ADDON   = 'plugin.video.kasbr'

# production url
# BASE_URL     = 'http://kasbr.com/'
# WIZARD_PAGE  = 'wizard/'



# a sample url only for test
BASE_URL     = 'http://192.168.5.37:8000/Desktop/'
WIZARD_PAGE  = 'resp.txt'